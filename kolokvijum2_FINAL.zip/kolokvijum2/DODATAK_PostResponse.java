// ============================================================
// DODATAK: PostResponse.java - KORISTI SAMO AKO TREBA
//
// Proveri u browseru sta API vraca:
//   https://app.beeceptor.com/mock-server/dummy-json/posts
//
// AKO vraca direktnu listu:  [ {...}, {...} ]
//   -> NE treba ti ovaj fajl, sve je OK
//
// AKO vraca objekat:  { "posts": [ {...}, {...} ] }
//   -> Kreiraj ovaj fajl i uredi ApiService.java i MainActivity.java
//
// ============================================================
// Desni klik na "com.example.kolukvijum2" paket
//   -> New -> Java Class -> ukucaj "PostResponse" -> Enter
// IZBRISI SVE i ubaci ovaj sadrzaj:
// ============================================================
package com.example.kolukvijum2;

import java.util.List;

public class PostResponse {
    public List<Post> posts;  // naziv mora da se poklapa sa kljucem u JSON-u
}


// ============================================================
// AKO KORISTIS PostResponse, promeni u ApiService.java:
//
//   STARO:  Call<List<Post>> getPosts();
//   NOVO:   Call<PostResponse> getPosts();
//
// I u MainActivity.java u switchLogika metodi:
//
//   STARO:  List<Post> svi = response.body();
//   NOVO:   List<Post> svi = response.body().posts;
// ============================================================
