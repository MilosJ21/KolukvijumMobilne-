// ============================================================
// KORAK 5: Post.java - NOVA KLASA
// Desni klik na "com.example.kolukvijum2" paket
//   -> New -> Java Class -> ukucaj "Post" -> Enter
// IZBRISI SVE i ubaci ovaj sadrzaj:
// ============================================================
package com.example.kolukvijum2;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "posts")
public class Post {

    @PrimaryKey(autoGenerate = true)
    public int id;          // auto ID u bazi (nije sa servera)

    public int userId;      // polja sa API-ja
    public int postId;
    public String title;
    public String body;
}
