// ============================================================
// KORAK 6: PostDao.java - NOVA KLASA
// Desni klik na "com.example.kolukvijum2" paket
//   -> New -> Java Class -> ukucaj "PostDao" -> Enter
// IZBRISI SVE i ubaci ovaj sadrzaj:
// ============================================================
package com.example.kolukvijum2;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import java.util.List;

@Dao
public interface PostDao {

    // Ubaci listu postova u bazu
    @Insert
    void insertAll(List<Post> posts);

    // Vrati SVE postove
    @Query("SELECT * FROM posts")
    List<Post> getAll();

    // Vrati PRVI post u tabeli (NE post sa id=1, nego prvi red!)
    @Query("SELECT * FROM posts LIMIT 1")
    Post getFirst();

    // Obrisi prvi post u tabeli
    @Query("DELETE FROM posts WHERE id = (SELECT id FROM posts LIMIT 1)")
    void deleteFirst();

    // Broj postova u bazi
    @Query("SELECT COUNT(*) FROM posts")
    int getCount();
}
