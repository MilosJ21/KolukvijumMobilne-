// ============================================================
// KORAK 8: ApiService.java - NOVA KLASA
// Desni klik na "com.example.kolukvijum2" paket
//   -> New -> Java Class -> ukucaj "ApiService" -> Enter
// IZBRISI SVE i ubaci ovaj sadrzaj:
//
// VAZNO: Ako API vraca { "posts": [...] } umjesto direktne liste,
//   vidi fajl DODATAK_PostResponse.java i zameni Call<List<Post>>
//   sa Call<PostResponse>
// ============================================================
package com.example.kolukvijum2;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {

    // GET zahtev na endpoint /posts
    @GET("posts")
    Call<List<Post>> getPosts();
}
