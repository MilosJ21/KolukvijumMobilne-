// ============================================================
// KORAK 9: RetrofitClient.java - NOVA KLASA
// Desni klik na "com.example.kolukvijum2" paket
//   -> New -> Java Class -> ukucaj "RetrofitClient" -> Enter
// IZBRISI SVE i ubaci ovaj sadrzaj:
// ============================================================
package com.example.kolukvijum2;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    // VAZNO: BASE_URL mora da se zavrsi sa /
    private static final String BASE_URL =
        "https://app.beeceptor.com/mock-server/dummy-json/";

    private static Retrofit retrofit;

    public static ApiService getService() {
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(BASE_URL)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofit.create(ApiService.class);
    }
}
