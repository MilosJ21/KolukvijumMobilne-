// ============================================================
// KORAK 7: AppDatabase.java - NOVA KLASA
// Desni klik na "com.example.kolukvijum2" paket
//   -> New -> Java Class -> ukucaj "AppDatabase" -> Enter
// IZBRISI SVE i ubaci ovaj sadrzaj:
// ============================================================
package com.example.kolukvijum2;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {Post.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {

    public abstract PostDao postDao();

    private static AppDatabase instance;

    public static AppDatabase getInstance(Context context) {
        if (instance == null) {
            instance = Room.databaseBuilder(
                    context.getApplicationContext(),
                    AppDatabase.class,
                    "app_database"
            )
            .allowMainThreadQueries()  // OK za kolokvijum
            .build();
        }
        return instance;
    }
}
