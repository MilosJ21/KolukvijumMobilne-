// ============================================================
// KORAK 10: MainActivity.java - KOMPLETAN FAJL
// Otvori: kotlin+java -> com.example.kolukvijum2 -> MainActivity.java
// IZBRISI SVE i ubaci ovaj sadrzaj:
// ============================================================
package com.example.kolukvijum2;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.widget.*;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.FileProvider;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import java.io.File;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    // ── UI ELEMENTI ──────────────────────────────────────────
    private TextView tvLokacija;
    private ImageButton ibKamera;
    private ImageView ivFoto;
    private Switch swPodaci;
    private Button btnObrisi;

    // ── GPS ──────────────────────────────────────────────────
    private FusedLocationProviderClient fusedLocationClient;

    // ── KAMERA ───────────────────────────────────────────────
    private Uri photoUri;
    private ActivityResultLauncher<Uri> cameraLauncher;

    // ── SENZORI ──────────────────────────────────────────────
    private SensorManager sensorManager;
    private Sensor gyroscope;
    private Sensor accelerometer;
    private float giroX, giroY, giroZ;

    // ── BAZA ─────────────────────────────────────────────────
    private AppDatabase db;
    private boolean postoviUpisani = false;

    // ── NOTIFIKACIJA ─────────────────────────────────────────
    private static final String KANAL_ID = "posts_kanal";

    // ── SENZOR LISTENER (AKCEL + ZIROSKOP) ───────────────────
    private final SensorEventListener senzorListener = new SensorEventListener() {
        @Override
        public void onSensorChanged(SensorEvent event) {

            if (event.sensor.getType() == Sensor.TYPE_GYROSCOPE) {
                // Zadatak 2: cuva vrednosti ziroskopa za Toast posle slikanja
                giroX = event.values[0];
                giroY = event.values[1];
                giroZ = event.values[2];
            }

            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                // Zadatak 6: menja tekst dugmeta u realnom vremenu
                String tekst = String.format("X:%.1f Y:%.1f Z:%.1f",
                        event.values[0], event.values[1], event.values[2]);
                btnObrisi.setText(tekst);
            }
        }

        @Override
        public void onAccuracyChanged(Sensor sensor, int accuracy) {
            // ne treba nista
        }
    };

    // ─────────────────────────────────────────────────────────
    // onCreate
    // ─────────────────────────────────────────────────────────
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Povezi UI elemente
        tvLokacija = findViewById(R.id.tvLokacija);
        ibKamera   = findViewById(R.id.ibKamera);
        ivFoto     = findViewById(R.id.ivFoto);
        swPodaci   = findViewById(R.id.swPodaci);
        btnObrisi  = findViewById(R.id.btnObrisi);

        // Inicijalizuj bazu
        db = AppDatabase.getInstance(this);

        // Inicijalizuj senzore
        sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
        gyroscope     = sensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE);
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);

        // Kreiraj notification channel
        kreirajKanal();

        // GPS
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        traziLokaciju();

        // Registruj camera launcher
        registrujKameraLauncher();

        // Postavi listenere
        ibKamera.setOnClickListener(v -> otvoriKameru());
        swPodaci.setOnCheckedChangeListener(this::switchLogika);
        btnObrisi.setOnClickListener(v -> obrisiPost());
    }

    // ─────────────────────────────────────────────────────────
    // onResume / onPause — upravljanje senzorima
    // ─────────────────────────────────────────────────────────
    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(senzorListener, gyroscope,
                SensorManager.SENSOR_DELAY_NORMAL);
        sensorManager.registerListener(senzorListener, accelerometer,
                SensorManager.SENSOR_DELAY_UI);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(senzorListener);
    }

    // ─────────────────────────────────────────────────────────
    // GPS — Zadatak 1
    // ─────────────────────────────────────────────────────────
    private void traziLokaciju() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 100);
            return;
        }
        fusedLocationClient.getLastLocation()
            .addOnSuccessListener(location -> {
                if (location != null) {
                    tvLokacija.setText(
                        "Lat: " + location.getLatitude()
                        + "\nLon: " + location.getLongitude());
                } else {
                    tvLokacija.setText("Lokacija nije dostupna");
                }
            });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
            String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 100
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            traziLokaciju();
        }
    }

    // ─────────────────────────────────────────────────────────
    // KAMERA — Zadatak 2
    // ─────────────────────────────────────────────────────────
    private void registrujKameraLauncher() {
        cameraLauncher = registerForActivityResult(
            new ActivityResultContracts.TakePicture(),
            success -> {
                if (success) {
                    // Prikazi sliku u ImageView
                    ivFoto.setImageURI(photoUri);

                    // Prikazi ziroskop u Toast-u
                    Toast.makeText(this,
                        "Ziroskop X:" + giroX
                        + " Y:" + giroY
                        + " Z:" + giroZ,
                        Toast.LENGTH_LONG).show();
                }
            });
    }

    private void otvoriKameru() {
        File photoFile = new File(
            getExternalFilesDir(android.os.Environment.DIRECTORY_PICTURES),
            "foto_kolokvijum.jpg"
        );
        photoUri = FileProvider.getUriForFile(
            this,
            getPackageName() + ".fileprovider",
            photoFile
        );
        cameraLauncher.launch(photoUri);
    }

    // ─────────────────────────────────────────────────────────
    // SWITCH — Zadatci 3 i 7
    // ─────────────────────────────────────────────────────────
    private void switchLogika(android.widget.CompoundButton buttonView, boolean isChecked) {

        if (isChecked) {
            // Switch ON

            if (!postoviUpisani) {
                // PRVI PUT: preuzmi sa interneta i upisi u bazu
                RetrofitClient.getService().getPosts()
                    .enqueue(new Callback<List<Post>>() {

                    @Override
                    public void onResponse(Call<List<Post>> call,
                            Response<List<Post>> response) {
                        if (response.isSuccessful() && response.body() != null) {
                            List<Post> svi = response.body();
                            // Uzmi prvih 10
                            List<Post> prvih10 = svi.subList(
                                    0, Math.min(10, svi.size()));
                            db.postDao().insertAll(prvih10);
                            postoviUpisani = true;
                            Toast.makeText(MainActivity.this,
                                "Upisano " + prvih10.size() + " postova!",
                                Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<List<Post>> call, Throwable t) {
                        Toast.makeText(MainActivity.this,
                            "Greska: " + t.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    }
                });

            } else {
                // SVAKI SLEDECI PUT: citaj iz baze
                Post prvi = db.postDao().getFirst();
                if (prvi != null) {
                    Toast.makeText(this,
                        "Title: " + prvi.title,
                        Toast.LENGTH_SHORT).show();
                }
            }

        } else {
            // Switch OFF — Zadatak 7

            // 1. Sacuvaj tekst iz TextView u SharedPreferences
            SharedPreferences prefs =
                getSharedPreferences("MojePrefs", MODE_PRIVATE);
            prefs.edit()
                .putString("tekst", tvLokacija.getText().toString())
                .apply();

            // 2. Ucitaj ime prvog kontakta i prikazi u TextView
            String ime = prviKontakt();
            tvLokacija.setText(ime != null ? ime : "Nema kontakata");
        }
    }

    // ─────────────────────────────────────────────────────────
    // BRISANJE POSTA — Zadatak 5
    // ─────────────────────────────────────────────────────────
    private void obrisiPost() {
        if (db.postDao().getCount() > 0) {
            db.postDao().deleteFirst();
            Toast.makeText(this, "Post obrisan.", Toast.LENGTH_SHORT).show();

            if (db.postDao().getCount() == 0) {
                posaljiNotifikaciju();
            }
        } else {
            posaljiNotifikaciju();
        }
    }

    // ─────────────────────────────────────────────────────────
    // NOTIFIKACIJA — Zadatak 5
    // ─────────────────────────────────────────────────────────
    private void kreirajKanal() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                KANAL_ID,
                "Postovi kanal",
                NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager nm =
                getSystemService(NotificationManager.class);
            nm.createNotificationChannel(channel);
        }
    }

    private void posaljiNotifikaciju() {
        NotificationCompat.Builder builder =
            new NotificationCompat.Builder(this, KANAL_ID)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Baza prazna")
                .setContentText("Nema vise postova!")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT);

        NotificationManagerCompat nm = NotificationManagerCompat.from(this);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.POST_NOTIFICATIONS)
                == PackageManager.PERMISSION_GRANTED) {
            nm.notify(1001, builder.build());
        } else {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
        }
    }

    // ─────────────────────────────────────────────────────────
    // KONTAKTI — Zadatak 7
    // ─────────────────────────────────────────────────────────
    private String prviKontakt() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.READ_CONTACTS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.READ_CONTACTS}, 102);
            return null;
        }
        Cursor cursor = getContentResolver().query(
            ContactsContract.Contacts.CONTENT_URI,
            new String[]{ContactsContract.Contacts.DISPLAY_NAME},
            null, null, null
        );
        if (cursor != null && cursor.moveToFirst()) {
            String ime = cursor.getString(0);
            cursor.close();
            return ime;
        }
        return null;
    }

}  // kraj MainActivity klase
